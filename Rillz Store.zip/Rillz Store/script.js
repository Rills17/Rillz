let cart = JSON.parse(localStorage.getItem("cart")) || {};
let totalCount = 0;
let totalPrice = 0;

initCart();

function initCart(){
  totalCount = 0;
  totalPrice = 0;
  for(let id in cart){
    totalCount += cart[id].qty;
    totalPrice += cart[id].price * cart[id].qty;
  }
  updateCartUI();
}

function addCart(name, id, price, img){
  if(cart[id]){
    cart[id].qty++;
  }else{
    cart[id] = {name, price, qty:1, img};
  }
  saveCart();
}

function saveCart(){
  localStorage.setItem("cart", JSON.stringify(cart));
  initCart();
}

function checkout(){
  let text = "Pesanan:%0A";
  for(let id in cart){
    let item = cart[id];
    text += `${item.name} (${id}) x${item.qty} - Rp ${item.price * item.qty}%0A`;
  }
  text += `%0ATotal: Rp ${totalPrice}`;

  window.open("https://forms.gle/WrTHErj4yqFcrLYu5","_blank");
}

function updateCartUI(){
  const badge = document.getElementById("badge");
  const cartItems = document.getElementById("cartItems");
  cartItems.innerHTML = "";

  if(totalCount === 0){
    badge.style.display = "none";
    cartItems.innerHTML = "<p class='empty'>Keranjang masih kosong</p>";
    return;
  }

  badge.style.display = "block";
  badge.innerText = totalCount;

  for(let id in cart){
    let item = cart[id];
    cartItems.innerHTML += `
      <div class="cart-item">
        <img src="${item.img}">
        <div>
          <strong>${item.name}</strong><br>
          ${item.qty} x Rp ${item.price}
        </div>
      </div>
    `;
  }
  cartItems.innerHTML += `<b>Total: Rp ${totalPrice}</b>`;
}

function toggleCart(){
  document.getElementById("cartPanel").classList.toggle("active");
}

function toggleTheme(){
  document.body.dataset.theme =
    document.body.dataset.theme === "dark" ? "" : "dark";
}

function scrollProduk(){
  document.getElementById("produk").scrollIntoView({behavior:"smooth"});
}

/* SEARCH & FILTER */
document.getElementById("searchInput").addEventListener("input", function(){
  let value = this.value.toLowerCase();
  document.querySelectorAll(".card").forEach(card=>{
    card.style.display =
      card.dataset.name.toLowerCase().includes(value) ? "block" : "none";
  });
});

document.getElementById("sortPrice").addEventListener("change", function(){
  let list = document.getElementById("productList");
  let cards = Array.from(list.children);
  let dir = this.value;

  cards.sort((a,b)=>{
    let pa = a.dataset.price;
    let pb = b.dataset.price;
    return dir === "low" ? pa - pb : pb - pa;
  });

  cards.forEach(c=>list.appendChild(c));
});